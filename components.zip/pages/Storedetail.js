import React from 'react'

const Storedetail = () => {
    return (
        <div>Storedetail</div>
    )
}

export default Storedetail