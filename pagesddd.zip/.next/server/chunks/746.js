"use strict";
exports.id = 746;
exports.ids = [746];
exports.modules = {

/***/ 2670:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Spinner = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-100 py-5 d-flex justify-content-center align-items-center h-100",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            class: "spinner-border text-black",
            role: "status",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                class: "visually-hidden",
                children: "Loading..."
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Spinner);


/***/ }),

/***/ 2681:
/***/ ((module) => {


module.exports = {
    NEXT_PUBLIC_APP_URL: "https://helloluvvy.com",
    // NEXT_PUBLIC_APP_URL: 'localhost:3000',
    APP_URL: "https://creativeitsols.com/system/public/",
    APP_KEY: "app_yZWYqQoDaeNDpe6YXZS3hiKcxN20vq0KQDCifCXm",
    DEFAULT_TITLE: "Coupon Codes",
    DEFAULT_DESC: " Coupon Codes",
    CONTAINER_TYPE: "wisde",
    FOOTER_ABOUT: "Helloluvvy is the website where you can find latest and verified coupons and promotion codes. Redeem and save now! Big Discounts. Simple Search. Get Code. Big Discount. Always Sale. The Best Price. Paste Code at Checkout. ALmost 5000+ Stores. Redeem Code Online.",
    FOOTER_DESC: "Helloluvvy may earn a commission when you purchase a product that is clicked through one of the link."
};


/***/ })

};
;