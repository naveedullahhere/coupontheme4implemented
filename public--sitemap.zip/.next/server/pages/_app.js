(() => {
var exports = {};
exports.id = 888;
exports.ids = [888,55,367];
exports.modules = {

/***/ 1274:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/logo-white.8bcb980c.png","height":363,"width":1050,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAXklEQVR42mP49++fDRAr/Pv/T+z310/K////5304LWTCk8VFjSA2A1CyGIjbgXj+v79/ZwMFmx8vzF/y5d6lCiB7IkgBOxCzArHYn5/feYCY4X6/Y8jtCgb22xUMDABWs0XPO7YhoQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":3});

/***/ }),

/***/ 9878:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layout_Footer1)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/assets/footerlogo.png
/* harmony default export */ const footerlogo = ({"src":"/_next/static/media/footerlogo.6609b121.png","height":80,"width":567,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAYAAADjAO9DAAAAJklEQVR4nGN88/nnUjZmptm8nCz3////L8bAwMABxN+A+D8Q8wMA2F0KPRUW58gAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":1});
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./public/settings/there_is_nothing_holding_me_back/config.js
var config = __webpack_require__(2681);
;// CONCATENATED MODULE: ./components/layout/Footer1.js






const Footer1 = ({ data  })=>{
    const [isPopupVisible, setIsPopupVisible] = (0,external_react_.useState)(false);
    const [isSlidingOut, setIsSlidingOut] = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        if (!localStorage.getItem("cookiesAccepted") && data?.is_cookies_policy_popup === 1) {
            // Delay popup by 3 seconds
            const timer = setTimeout(()=>{
                setIsPopupVisible(true);
            }, 3000);
            // Cleanup timeout on unmount
            return ()=>clearTimeout(timer);
        }
    }, [
        data?.is_cookies_policy_popup
    ]);
    const handleAcceptCookies = ()=>{
        const timestampNow = new Date().getTime(); // Current time in milliseconds
        const expirationTime = timestampNow + 3600000; // 1 hour (3600000 milliseconds) from now
        // Save acceptance and expiration timestamp
        localStorage.setItem("cookiesAccepted", "true");
        localStorage.setItem("cookieExpiration", expirationTime);
        setIsSlidingOut(true); // Start slide-out animation
        setTimeout(()=>{
            setIsPopupVisible(false); // Remove popup from DOM
        }, 300);
        // Start checking for expiration in real-time
        startRealTimeCookieCheck();
    };
    const startRealTimeCookieCheck = ()=>{
        const interval = setInterval(()=>{
            const timestampNow = new Date().getTime();
            const expirationTime = localStorage.getItem("cookieExpiration");
            // If expiration time has passed, remove the cookie
            if (expirationTime && timestampNow > expirationTime) {
                localStorage.removeItem("cookiesAccepted");
                localStorage.removeItem("cookieExpiration");
                console.log("Cookies have been removed in real-time!");
                clearInterval(interval); // Stop the interval after removal
            }
        }, 1000); // Check every second
    };
    // Call this function on page load to ensure consistency
    startRealTimeCookieCheck();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container-fluid bg-footer  footer-1",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-md-3 my-auto text-center text-md-start",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                href: "/",
                                children: [
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: data?.url + "/" + data?.logo?.header || footerlogo,
                                        fill: true,
                                        className: "footer1-logo w-40 position-relative"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-md-3 text-white text-center my-auto",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "my-auto text-footer ",
                                children: " All Right Reserved"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "col-md-6 footer-link text-center my-auto",
                            children: [
                                data?.pages?.map((item)=>{
                                    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: `/pages/${item.slug}`,
                                        children: item.name
                                    });
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/all-stores",
                                    children: "Stores"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/contact",
                                    children: "Contact Us"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/category",
                                    children: "Categories"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        class: "fab fa-twitter",
                                        "aria-hidden": "true"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        class: "fab fa-pinterest",
                                        "aria-hidden": "true"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        class: "fab fa-facebook",
                                        "aria-hidden": "true"
                                    })
                                })
                            ]
                        })
                    ]
                })
            }),
            isPopupVisible && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `cookie-policy-containers ${isSlidingOut ? "slide-out" : "slide-up"}`,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "alert alert-black alert-dismissible fade show bg-black text-white m-auto py-4",
                    role: "alert",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row align-items-center",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-10",
                                children: [
                                    data?.cookies_policy_popup_text || "",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        className: "text-white",
                                        href: "/pages/cookies-policy",
                                        children: "Cookies Policy"
                                    }),
                                    " and ",
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        className: "text-white",
                                        href: "/pages/privacy-policy",
                                        children: "Privacy Policy"
                                    }),
                                    "."
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-2 text-end",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: "btn btn-light",
                                    onClick: handleAcceptCookies,
                                    children: "OKAY"
                                })
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const layout_Footer1 = (Footer1);


/***/ }),

/***/ 7314:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2681);
/* harmony import */ var _public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _public_assets_logo_white_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1274);






const Footer2 = ({ season , country , data  })=>{
    const [isPopupVisible, setIsPopupVisible] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const [isSlidingOut, setIsSlidingOut] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        if (!localStorage.getItem("cookiesAccepted") && data?.is_cookies_policy_popup === 1) {
            // Delay popup by 3 seconds
            const timer = setTimeout(()=>{
                setIsPopupVisible(true);
            }, 3000);
            // Cleanup timeout on unmount
            return ()=>clearTimeout(timer);
        }
    }, [
        data?.is_cookies_policy_popup
    ]);
    const handleAcceptCookies = ()=>{
        const timestampNow = new Date().getTime(); // Current time in milliseconds
        const expirationTime = timestampNow + 3600000; // 1 hour (3600000 milliseconds) from now
        // Save acceptance and expiration timestamp
        localStorage.setItem("cookiesAccepted", "true");
        localStorage.setItem("cookieExpiration", expirationTime);
        setIsSlidingOut(true); // Start slide-out animation
        setTimeout(()=>{
            setIsPopupVisible(false); // Remove popup from DOM
        }, 300);
        // Start checking for expiration in real-time
        startRealTimeCookieCheck();
    };
    const startRealTimeCookieCheck = ()=>{
        const interval = setInterval(()=>{
            const timestampNow = new Date().getTime();
            const expirationTime = localStorage.getItem("cookieExpiration");
            // If expiration time has passed, remove the cookie
            if (expirationTime && timestampNow > expirationTime) {
                localStorage.removeItem("cookiesAccepted");
                localStorage.removeItem("cookieExpiration");
                console.log("Cookies have been removed in real-time!");
                clearInterval(interval); // Stop the interval after removal
            }
        }, 1000); // Check every second
    };
    startRealTimeCookieCheck();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-footer",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "container py-4 ",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "row",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "col-md-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        href: "/",
                                        className: "footer-2-logo",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            src: data?.url + "/" + data?.logo?.footer || _public_assets_logo_white_png__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
                                            alt: "",
                                            className: "position-relative my-1 header-logo w-100",
                                            style: {
                                                objectFit: "contain"
                                            },
                                            fill: true
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-white footer-desc",
                                        children: _public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_1__.FOOTER_ABOUT
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                        className: "footer-link footer2-icon  p-0 text-white pt-1 d-flex",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    href: "",
                                                    children: [
                                                        " ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                            className: "fab fa-facebook-f"
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    href: "",
                                                    children: [
                                                        " ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                            className: "fab fa-pinterest-p"
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    href: "",
                                                    children: [
                                                        " ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                            className: "fab fa-twitter "
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "col-md-8 row ",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-md-4 ",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                className: "my-auto text-white fw-bolder",
                                                children: "About US"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                className: "footer-link p-0 text-white pt-3",
                                                children: [
                                                    data?.pages?.map((item)=>{
                                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            className: "mb-1",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                                className: "ms-0",
                                                                href: `/pages/${item.slug}`,
                                                                children: item.name
                                                            })
                                                        });
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: "mb-1",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                            className: "ms-0",
                                                            href: "/contact",
                                                            children: "Contact Us"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-md-4 ",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                className: "my-auto text-white fw-bolder",
                                                children: "Shop By Country"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                className: "footer-link p-0 text-white pt-3",
                                                children: country?.slice(0, 6).map((countrydd)=>{
                                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: "mb-1",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                            className: "ms-0",
                                                            href: `/country/${countrydd.slug}`,
                                                            children: countrydd.name
                                                        })
                                                    });
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-md-4 ",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                className: "my-auto text-white fw-bolder",
                                                children: "What's Trending"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                className: "footer-link p-0 text-white pt-3",
                                                children: season?.data?.slice(0, 6).map((seasondd)=>{
                                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: "mb-1",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                            className: "ms-0",
                                                            href: `/season/${seasondd.slug}`,
                                                            children: seasondd.name
                                                        })
                                                    });
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                class: "col-md-12",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    class: "copright_text",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                            className: "text-white opacity-1"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "text-white",
                                            children: _public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_1__.FOOTER_DESC
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            }),
            isPopupVisible && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `cookie-policy-containers ${isSlidingOut ? "slide-out" : "slide-up"}`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "alert alert-black alert-dismissible fade show bg-black text-white m-auto py-4",
                    role: "alert",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "row align-items-center",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "col-10",
                                children: [
                                    data?.cookies_policy_popup_text || "",
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        className: "text-white",
                                        href: "/pages/cookies-policy",
                                        children: "Cookies Policy"
                                    }),
                                    " and ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        className: "text-white",
                                        href: "/pages/privacy-policy",
                                        children: "Privacy Policy"
                                    }),
                                    "."
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-2 text-end",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "btn btn-light",
                                    onClick: handleAcceptCookies,
                                    children: "OKAY"
                                })
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer2);


/***/ }),

/***/ 7468:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9816);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6201);
/* harmony import */ var _public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2681);
/* harmony import */ var _public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hot_toast__WEBPACK_IMPORTED_MODULE_4__]);
react_hot_toast__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const Footer4 = ({ data  })=>{
    const [email, setEmail] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    let FOOTER_CONFIG = data?.footer?.menu;
    let TRENDING_BLOGS = data?.blogs;
    const handleEmailSubmit = async (e)=>{
        e.preventDefault();
        if (!email || !/\S+@\S+\.\S+/.test(email)) {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_4__.toast.error("Please enter a valid email address");
            return;
        }
        setIsLoading(true);
        try {
            const response = await fetch(`${_public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_5__.APP_URL}api/subscribe`, {
                headers: {
                    "Content-Type": "application/json"
                },
                method: "POST",
                body: JSON.stringify({
                    email,
                    key: _public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_5__.APP_KEY
                })
            });
            const data = await response.json();
            if (data.success) {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_4__.toast.success(data.message);
                setEmail("");
            } else {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_4__.toast.error(data.message);
            }
        } catch (err) {
            console.error(err);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_4__.toast.error("Something went wrong! Please try again.");
        } finally{
            setIsLoading(false);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", {
        className: "jsx-18fed7fc27c0e67" + " " + "bg-footer",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "jsx-18fed7fc27c0e67" + " " + "container",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "jsx-18fed7fc27c0e67" + " " + "row",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "jsx-18fed7fc27c0e67" + " " + "col-md-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "jsx-18fed7fc27c0e67" + " " + "footer-title text-footer font-modernMTPro",
                                        children: "Trending"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                        className: "jsx-18fed7fc27c0e67" + " " + "footer-links",
                                        children: TRENDING_BLOGS.map((blogs, linkIndex)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "jsx-18fed7fc27c0e67",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    href: `/blog/${blogs.slug}`,
                                                    className: "footer-link text-footer",
                                                    children: blogs.title
                                                })
                                            }, blogs.id))
                                    })
                                ]
                            }),
                            FOOTER_CONFIG?.columns.map((column, columnIndex)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "jsx-18fed7fc27c0e67" + " " + "col-md-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                            className: "jsx-18fed7fc27c0e67" + " " + "footer-title text-footer font-modernMTPro  ",
                                            children: column.title
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                            className: "jsx-18fed7fc27c0e67" + " " + "footer-links",
                                            children: column.links.map((link, linkIndex)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    className: "jsx-18fed7fc27c0e67",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        href: link.url,
                                                        className: "footer-link text-footer",
                                                        children: link.text
                                                    })
                                                }, linkIndex))
                                        })
                                    ]
                                }, columnIndex)),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "jsx-18fed7fc27c0e67" + " " + "col-md-4 newsletter-column",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "jsx-18fed7fc27c0e67" + " " + "newsletter-title text-footer font-modernMTPro",
                                        children: FOOTER_CONFIG?.newsletter.title
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                                        onSubmit: handleEmailSubmit,
                                        className: "jsx-18fed7fc27c0e67" + " " + "newsletter-form",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "jsx-18fed7fc27c0e67" + " " + "newsletter-input-group",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    type: "email",
                                                    placeholder: FOOTER_CONFIG?.newsletter.placeholder,
                                                    value: email,
                                                    onChange: (e)=>setEmail(e.target.value),
                                                    required: true,
                                                    disabled: isLoading,
                                                    className: "jsx-18fed7fc27c0e67" + " " + "newsletter-input"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    type: "submit",
                                                    disabled: isLoading,
                                                    className: "jsx-18fed7fc27c0e67" + " " + "newsletter-button",
                                                    children: isLoading ? "Subscribing..." : FOOTER_CONFIG?.newsletter.buttonText
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "jsx-18fed7fc27c0e67" + " " + "footer-social",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                            className: "jsx-18fed7fc27c0e67" + " " + "social-links",
                            children: FOOTER_CONFIG?.socialLinks.map((social, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: "jsx-18fed7fc27c0e67",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        href: social.url,
                                        className: "social-link text-footer",
                                        "aria-label": social.ariaLabel,
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        children: social.text
                                    })
                                }, index))
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "jsx-18fed7fc27c0e67" + " " + "footer-copyright",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            className: "jsx-18fed7fc27c0e67" + " " + "text-footer",
                            children: [
                                "\xa9 ",
                                FOOTER_CONFIG?.copyright.year,
                                ",",
                                " ",
                                FOOTER_CONFIG?.copyright.company,
                                " |",
                                " ",
                                FOOTER_CONFIG?.copyright.links.map((link, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "jsx-18fed7fc27c0e67" + " " + "text-footer",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                href: link.url,
                                                className: "copyright-link text-footer",
                                                children: link.text
                                            }),
                                            index < FOOTER_CONFIG?.copyright.links.length - 1 && " | "
                                        ]
                                    }, index)),
                                " ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "jsx-18fed7fc27c0e67" + " " + "privacy-icon",
                                    children: FOOTER_CONFIG?.copyright.privacyIcon
                                })
                            ]
                        })
                    })
                ]
            }),
            react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
                id: "18fed7fc27c0e67",
                children: ".bg-footer.jsx-18fed7fc27c0e67{width:100%;padding:60px 0;color:#000}.footer-container.jsx-18fed7fc27c0e67{margin:0 auto;padding:0 40px}.footer-main.jsx-18fed7fc27c0e67{display:grid;grid-template-columns:repeat(4,1fr);gap:40px;margin-bottom:40px}.footer-column.jsx-18fed7fc27c0e67{display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;-moz-box-orient:vertical;-moz-box-direction:normal;-ms-flex-direction:column;flex-direction:column}.footer-title.jsx-18fed7fc27c0e67{font-size:16px;font-weight:700;letter-spacing:.5px;margin-bottom:20px;text-transform:uppercase;line-height:1.4}.newsletter-title.jsx-18fed7fc27c0e67{font-size:13px;font-weight:700;letter-spacing:.5px;margin-bottom:20px;text-transform:uppercase;line-height:1.4}.footer-links.jsx-18fed7fc27c0e67{list-style:none;padding:0;margin:0;display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;-moz-box-orient:vertical;-moz-box-direction:normal;-ms-flex-direction:column;flex-direction:column;gap:12px}.footer-link.jsx-18fed7fc27c0e67{font-size:13px;color:var(--footer-text)!important;text-decoration:none;-webkit-transition:opacity.3s ease;-moz-transition:opacity.3s ease;-o-transition:opacity.3s ease;transition:opacity.3s ease;line-height:1.6}.footer-link.jsx-18fed7fc27c0e67:hover{opacity:.7}.newsletter-column.jsx-18fed7fc27c0e67{grid-column:4}.newsletter-form.jsx-18fed7fc27c0e67{margin-top:15px;margin-bottom:15px}.newsletter-input-group.jsx-18fed7fc27c0e67{display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;gap:0;margin-bottom:12px}.newsletter-input.jsx-18fed7fc27c0e67{-webkit-box-flex:1;-webkit-flex:1;-moz-box-flex:1;-ms-flex:1;flex:1;padding:12px 16px;border:1px solid#d3d3d3;font-size:13px;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0;outline:none;background:#fff;color:#000}.newsletter-input.jsx-18fed7fc27c0e67:disabled{background-color:#f5f5f5;cursor:not-allowed}.newsletter-input.jsx-18fed7fc27c0e67::-webkit-input-placeholder{color:#999}.newsletter-input.jsx-18fed7fc27c0e67:-moz-placeholder{color:#999}.newsletter-input.jsx-18fed7fc27c0e67::-moz-placeholder{color:#999}.newsletter-input.jsx-18fed7fc27c0e67:-ms-input-placeholder{color:#999}.newsletter-input.jsx-18fed7fc27c0e67::-ms-input-placeholder{color:#999}.newsletter-input.jsx-18fed7fc27c0e67::placeholder{color:#999}.newsletter-input.jsx-18fed7fc27c0e67:focus{border-color:#000}.newsletter-button.jsx-18fed7fc27c0e67{background-color:#000;color:#fff;border:none;padding:12px 20px;font-size:13px;font-weight:700;letter-spacing:.5px;cursor:pointer;-webkit-transition:background-color.3s ease;-moz-transition:background-color.3s ease;-o-transition:background-color.3s ease;transition:background-color.3s ease;padding:12px 32px}.newsletter-button.jsx-18fed7fc27c0e67:disabled{background-color:#666;cursor:not-allowed}.newsletter-button.jsx-18fed7fc27c0e67:hover:not(:disabled){background-color:#222}.footer-social.jsx-18fed7fc27c0e67{text-align:center;padding:20px 0}.social-links.jsx-18fed7fc27c0e67{list-style:none;padding:0;margin:0;display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-webkit-justify-content:center;-moz-box-pack:center;-ms-flex-pack:center;justify-content:center;gap:20px}.social-link.jsx-18fed7fc27c0e67{display:-webkit-inline-box;display:-webkit-inline-flex;display:-moz-inline-box;display:-ms-inline-flexbox;display:inline-flex;-webkit-box-align:center;-webkit-align-items:center;-moz-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-moz-box-pack:center;-ms-flex-pack:center;justify-content:center;width:24px;height:24px;color:#000;text-decoration:none;font-size:14px;font-weight:600;-webkit-transition:opacity.3s ease;-moz-transition:opacity.3s ease;-o-transition:opacity.3s ease;transition:opacity.3s ease}.social-link.jsx-18fed7fc27c0e67:hover{opacity:.6}.footer-copyright.jsx-18fed7fc27c0e67{text-align:center;border-top:1px solid#e0e0e0;padding-top:20px}.footer-copyright.jsx-18fed7fc27c0e67 p.jsx-18fed7fc27c0e67{font-size:12px;color:#666;margin:0;line-height:1.6}.copyright-link.jsx-18fed7fc27c0e67{color:#000;text-decoration:none;-webkit-transition:opacity.3s ease;-moz-transition:opacity.3s ease;-o-transition:opacity.3s ease;transition:opacity.3s ease}.copyright-link.jsx-18fed7fc27c0e67:hover{opacity:.7}.privacy-icon.jsx-18fed7fc27c0e67{margin:0 4px}@media(max-width:1024px){.footer-main.jsx-18fed7fc27c0e67{grid-template-columns:repeat(2,1fr);gap:30px}.newsletter-column.jsx-18fed7fc27c0e67{grid-column:1/-1}}@media(max-width:768px){.footer-container.jsx-18fed7fc27c0e67{padding:0 20px}.footer-main.jsx-18fed7fc27c0e67{grid-template-columns:1fr;gap:30px}.newsletter-input-group.jsx-18fed7fc27c0e67{-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;-moz-box-orient:vertical;-moz-box-direction:normal;-ms-flex-direction:column;flex-direction:column}.newsletter-button.jsx-18fed7fc27c0e67{width:100%}.footer-title.jsx-18fed7fc27c0e67{font-size:16px}.footer-link.jsx-18fed7fc27c0e67{font-size:12px!important}}"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer4);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7199:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layout_Header1)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/assets/logo.png
/* harmony default export */ const logo = ({"src":"/_next/static/media/logo.c2d19fe3.png","height":81,"width":568,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAYAAADjAO9DAAAAJklEQVR4nGPMWHdv0dv71+atLm+7LzdrvuiPP384GBgZvzFAAB8ALXoNyZuolTMAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":1});
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./pages/country/[slug].js
var _slug_ = __webpack_require__(2988);
// EXTERNAL MODULE: ./public/settings/there_is_nothing_holding_me_back/config.js
var config = __webpack_require__(2681);
;// CONCATENATED MODULE: ./components/layout/Header1.js








const Header1 = ({ data , category , season , coupons , country  })=>{
    const [searchQuery, setSearchQuery] = (0,external_react_.useState)([]);
    const [isActive, setIsActive] = (0,external_react_.useState)(false);
    const [query, setQuery] = (0,external_react_.useState)("");
    const [isLoading, setIsLoading] = (0,external_react_.useState)(false);
    const handleSearch = (e)=>{
        setQuery(e);
        if (query.length >= 1) {
            setIsActive(true);
            setIsLoading(true);
            fetch(`${config.APP_URL}api/store?key=${config.APP_KEY}&search=${e}`).then((res)=>res.json()).then((results)=>{
                let query = [];
                results?.data?.map((item)=>query.push({
                        name: item.name,
                        slug: item.slug
                    }));
                setIsLoading(false);
                setSearchQuery(query);
            });
        } else {
            setIsLoading(false);
            setIsActive(false);
            setSearchQuery([]);
        }
    };
    const closeMenu = (0,external_react_.useRef)();
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
            className: "navbar navbar-expand-lg bg-header",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        className: "navbar-brand col-md-2 col-4",
                        href: "/",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: data?.url + "/" + data?.logo?.header || logo,
                            alt: "",
                            className: "position-relative my-1 header-logo w-100",
                            fill: true
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "navbar-toggler shadow-none ",
                        ref: closeMenu,
                        type: "button",
                        "data-bs-toggle": "collapse",
                        "data-bs-target": "#navbarSupportedContent",
                        "aria-controls": "navbarSupportedContent",
                        "aria-expanded": "false",
                        "aria-label": "Toggle navigation",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            width: "36",
                            height: "36",
                            fill: "currentColor",
                            class: "bi bi-justify text-header",
                            viewBox: "0 0 16 16",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                "fill-rule": "evenodd",
                                d: "M2 12.5a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5zm0-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5zm0-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5zm0-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5z"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "collapse navbar-collapse",
                        id: "navbarSupportedContent",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "navbar-nav ms-2 mb-2 mb-lg-0 nav-css ",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "nav-item",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            className: "nav-link active text-header",
                                            href: "/all-stores",
                                            children: "Stores"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "nav-item dropdown",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                className: "nav-link dropdown-toggle  text-header",
                                                href: "/category",
                                                children: "Category"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                className: "dropdown-menu rounded-0",
                                                children: category?.slice(0, 10).map((cat)=>{
                                                    return /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            className: "dropdown-item dropdown-item-hov ",
                                                            href: `/category/${cat.slug}`,
                                                            children: cat.name
                                                        })
                                                    });
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "nav-item dropdown",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                className: "nav-link dropdown-toggle text-header",
                                                href: "#",
                                                role: "button",
                                                "data-bs-toggle": "dropdown",
                                                "aria-expanded": "false",
                                                children: "Coupons"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                className: "dropdown-menu rounded-0",
                                                children: coupons?.slice(0, 10).map((coupondd)=>{
                                                    return /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            className: "dropdown-item dropdown-item-hov",
                                                            href: `/coupon/${coupondd.slug}`,
                                                            children: coupondd.name
                                                        })
                                                    });
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "nav-item dropdown",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                className: "nav-link dropdown-toggle text-header",
                                                href: "#",
                                                role: "button",
                                                "data-bs-toggle": "dropdown",
                                                "aria-expanded": "false",
                                                children: "Season"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                className: "dropdown-menu rounded-0",
                                                children: season?.slice(0, 10).map((seasondd)=>{
                                                    return /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            className: "dropdown-item dropdown-item-hov",
                                                            href: `/season/${seasondd.slug}`,
                                                            children: seasondd.name
                                                        })
                                                    });
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "nav-item dropdown",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                className: "nav-link dropdown-toggle text-header",
                                                href: "#",
                                                role: "button",
                                                "data-bs-toggle": "dropdown",
                                                "aria-expanded": "false",
                                                children: "Country"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                className: "dropdown-menu rounded-0",
                                                children: country?.slice(0, 10).map((countrydd)=>{
                                                    return /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            className: "dropdown-item dropdown-item-hov",
                                                            href: `/country/${countrydd.slug}`,
                                                            children: countrydd.name
                                                        })
                                                    });
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "nav-item dropdown memorial-btn",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: `${data.header.button_url}`,
                                            className: "button header-btn-bg header-btn-text",
                                            children: data?.header?.button_text
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                className: "d-flex mx-auto position-relative col-md-3 flex-column",
                                role: "search",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        className: "form-control me-2 rounded-0 ",
                                        type: "search",
                                        placeholder: "Search...",
                                        "aria-label": "Search",
                                        onChange: (e)=>handleSearch(e.target.value)
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        class: "w-100 z-2 top-100 pl-0 position-absolute header-search",
                                        children: isActive && isLoading ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            class: "list-group",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                class: "list-group-item list-group-item-action z-index-2  rounded-0",
                                                children: "Loading..."
                                            })
                                        }) : searchQuery.length ? searchQuery.map((item)=>{
                                            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                class: "list-group",
                                                onClick: ()=>{
                                                    setQuery("");
                                                    setIsLoading(false);
                                                    setIsActive(false);
                                                    setSearchQuery([]);
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: `/store/${item.slug}`,
                                                    class: "list-group-item list-group-item-action rounded-0 ",
                                                    children: item.name
                                                })
                                            });
                                        }) : query.length ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            class: "list-group",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                class: "list-group-item list-group-item-action rounded-0",
                                                children: "No Result Found"
                                            })
                                        }) : ""
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/*#__PURE__*/ jsx_runtime_.jsx("style", {});
/* harmony default export */ const layout_Header1 = (Header1);


/***/ }),

/***/ 6891:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _public_assets_logo_white_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1274);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2681);
/* harmony import */ var _public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_5__);






const Header2 = ({ data , category , season , coupons , country  })=>{
    const [searchQuery, setSearchQuery] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    const [isActive, setIsActive] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [query, setQuery] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const handleSearch = (e)=>{
        setQuery(e);
        if (query.length >= 1) {
            setIsActive(true);
            setIsLoading(true);
            fetch(`${_public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_5__.APP_URL}api/store?key=${_public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_5__.APP_KEY}&search=${e}`).then((res)=>res.json()).then((results)=>{
                let query = [];
                results?.data?.map((item)=>query.push({
                        name: item.name,
                        slug: item.slug
                    }));
                setIsLoading(false);
                setSearchQuery(query);
            });
        } else {
            setIsLoading(false);
            setIsActive(false);
            setSearchQuery([]);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                className: "navbar navbar-expand-lg bg-header px-3 py-2",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "container-fluid",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                            className: "navbar-brand col-md-2 col-4",
                            href: "/",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                src: data?.url + "/" + data?.logo?.header || _public_assets_logo_white_png__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
                                alt: "",
                                className: "position-relative my-1 header-logo w-100",
                                fill: true
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "navbar-toggler shadow-none",
                            type: "button",
                            "data-bs-toggle": "collapse",
                            "data-bs-target": "#navbarSupportedContent",
                            "aria-controls": "navbarSupportedContent",
                            "aria-expanded": "false",
                            "aria-label": "Toggle navigation",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                xmlns: "http://www.w3.org/2000/svg",
                                width: "36",
                                height: "36",
                                fill: "currentColor",
                                class: "bi bi-justify text-header",
                                viewBox: "0 0 16 16",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                    "fill-rule": "evenodd",
                                    d: "M2 12.5a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5zm0-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5zm0-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5zm0-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5z"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "collapse navbar-collapse w-75 mt-2 h2 position-relative",
                            id: "navbarSupportedContent",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                className: "mx-auto mx-md-0 d-flex w-75 rounded-2",
                                role: "search",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        className: "form-control rounded-1",
                                        type: "search",
                                        placeholder: "Search 5000+ Brands Coupons & Promo Codes",
                                        "aria-label": "Search",
                                        onChange: (e)=>handleSearch(e.target.value),
                                        value: query
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        class: "w-75 top-100 pl-0 z-2 position-absolute header-search z-2",
                                        children: isActive && isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            class: "list-group",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                class: "list-group-item list-group-item-action rounded-0 z-2",
                                                children: "Loading..."
                                            })
                                        }) : searchQuery.length ? searchQuery.map((item)=>{
                                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                class: "list-group",
                                                onClick: ()=>{
                                                    setQuery("");
                                                    setIsLoading(false);
                                                    setIsActive(false);
                                                    setSearchQuery([]);
                                                },
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    href: `/store/${item.slug}`,
                                                    class: "list-group-item list-group-item-action rounded-0",
                                                    children: item.name
                                                })
                                            });
                                        }) : query.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            class: "list-group",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                class: "list-group-item list-group-item-action rounded-0",
                                                children: "No Result Found"
                                            })
                                        }) : ""
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                className: "navbar navbar-expand-lg py-0 bg-white",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "container ",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "collapse navbar-collapse",
                        id: "navbarSupportedContent",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                            className: "navbar-nav mb-2 mb-lg-0 nav-css",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: "nav-item ",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        className: "nav-link",
                                        href: "/all-stores",
                                        children: "All Stores"
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    className: "nav-item dropdown",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            href: "/category",
                                            className: "nav-link dropdown-toggle",
                                            children: "Category"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                            className: "dropdown-menu rounded-0 header-dd-2",
                                            children: category?.slice(0, 10).map((cat)=>{
                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                        className: "dropdown-item dropdown-item-hov ",
                                                        href: `/category/${cat.slug}`,
                                                        children: cat.name
                                                    })
                                                });
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    className: "nav-item dropdown",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            className: "nav-link dropdown-toggle",
                                            href: "#",
                                            role: "button",
                                            "data-bs-toggle": "dropdown",
                                            "aria-expanded": "false",
                                            children: "Coupon"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                            className: "dropdown-menu rounded-0 header-dd-2",
                                            children: coupons?.slice(0, 10).map((coupondd)=>{
                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                        className: "dropdown-item dropdown-item-hov",
                                                        href: `/coupon/${coupondd.slug}`,
                                                        children: coupondd.name
                                                    })
                                                });
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    className: "nav-item dropdown",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            className: "nav-link dropdown-toggle",
                                            href: "#",
                                            role: "button",
                                            "data-bs-toggle": "dropdown",
                                            "aria-expanded": "false",
                                            children: "Seasons"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                            className: "dropdown-menu  rounded-0 header-dd-2",
                                            children: season?.slice(0, 10).map((seasondd)=>{
                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                        className: "dropdown-item dropdown-item-hov",
                                                        href: `/season/${seasondd.slug}`,
                                                        children: seasondd.name
                                                    })
                                                });
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: "nav-item dropdown memorial-btn",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        href: `${data.header.button_url}`,
                                        className: "button header-btn-bg header-btn-text",
                                        children: data?.header?.button_text
                                    })
                                })
                            ]
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header2);


/***/ }),

/***/ 8015:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _public_assets_logo_white_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1274);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2681);
/* harmony import */ var _public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_5__);






const Header2 = ({ data , category , season , coupons , country  })=>{
    const [searchQuery, setSearchQuery] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    const [isActive, setIsActive] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [query, setQuery] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const handleSearch = (e)=>{
        setQuery(e);
        if (query.length >= 1) {
            setIsActive(true);
            setIsLoading(true);
            fetch(`${_public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_5__.APP_URL}api/store?key=${_public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_5__.APP_KEY}&search=${e}`).then((res)=>res.json()).then((results)=>{
                let query = [];
                results?.data?.map((item)=>query.push({
                        name: item.name,
                        slug: item.slug
                    }));
                setIsLoading(false);
                setSearchQuery(query);
            });
        } else {
            setIsLoading(false);
            setIsActive(false);
            setSearchQuery([]);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                className: "navbar bg-header py-2",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "container",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "row w-100",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-12 d-flex justify-content-center",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                href: "/",
                                className: "navbar-brand mx-auto",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    src: data?.url + "/" + data?.logo?.header || _public_assets_logo_white_png__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
                                    alt: "Logo",
                                    className: "header-logo",
                                    width: 180,
                                    height: 60
                                })
                            })
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                className: "navbar bg-header py-0",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "container-fluid",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "row w-100 mx-auto justify-content-end position-relative",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "col-md-4 col-12 position-relative",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "input-group input-group-sm",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: "form-control rounded-0 header-search-input",
                                            type: "search",
                                            placeholder: "Search brands & coupons",
                                            onChange: (e)=>handleSearch(e.target.value),
                                            value: query
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: "btn btn-dark header-search-btn",
                                            type: "button",
                                            children: "Search"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "position-absolute w-100 top-100 header-search z-2",
                                    children: isActive && (isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "list-group",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "list-group-item",
                                            children: "Loading..."
                                        })
                                    }) : searchQuery.length ? searchQuery.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "list-group",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                href: `/store/${item.slug}`,
                                                className: "list-group-item list-group-item-action",
                                                onClick: ()=>{
                                                    setQuery("");
                                                    setIsActive(false);
                                                    setSearchQuery([]);
                                                },
                                                children: item.name
                                            })
                                        }, item.slug)) : query.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "list-group",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "list-group-item",
                                            children: "No Result Found"
                                        })
                                    }) : null)
                                })
                            ]
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                className: "navbar navbar-expand-lg bg-white py-0 bordertop",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "container justify-content-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "navbar-toggler shadow-none my-2",
                            type: "button",
                            "data-bs-toggle": "collapse",
                            "data-bs-target": "#mainMenu",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "navbar-toggler-icon"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "collapse navbar-collapse justify-content-center",
                            id: "mainMenu",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: "navbar-nav nav-css",
                                children: [
                                    data?.blog_categories?.map((item)=>{
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: "nav-item px-3",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                className: "nav-link",
                                                href: `/blogs/${item.slug}`,
                                                children: item.name
                                            })
                                        });
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "nav-item dropdown px-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                className: "nav-link dropdown-toggle",
                                                href: "/all-stores",
                                                children: "Coupons"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                className: "dropdown-menu rounded-0",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                            className: "nav-link nav-item ",
                                                            href: "/all-stores",
                                                            children: "All Stores"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                        className: "dropdown",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                className: "nav-link nav-item dropdown-toggle",
                                                                href: "/all-stores",
                                                                children: "Categories"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                                className: "dropdown-menu rounded-0",
                                                                children: category?.slice(0, 10).map((cat)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                            className: "dropdown-item",
                                                                            href: `/category/${cat.slug}`,
                                                                            children: cat.name
                                                                        })
                                                                    }, cat.slug))
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header2);


/***/ }),

/***/ 8510:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ App)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9816);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6764);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_layout_Header1__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7199);
/* harmony import */ var _components_layout_Header2__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6891);
/* harmony import */ var _Layout__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8321);
/* harmony import */ var _components_layout_Footer1__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9878);
/* harmony import */ var _components_layout_Footer2__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7314);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2681);
/* harmony import */ var _public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_Spinner__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2670);
/* harmony import */ var _components_layout_Header4__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8015);
/* harmony import */ var _components_layout_Footer4__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7468);
/* harmony import */ var _public_fonts_font_dec_css__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4512);
/* harmony import */ var _public_fonts_font_dec_css__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_public_fonts_font_dec_css__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_15__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layout_Footer4__WEBPACK_IMPORTED_MODULE_13__]);
_components_layout_Footer4__WEBPACK_IMPORTED_MODULE_13__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
















const Toaster = next_dynamic__WEBPACK_IMPORTED_MODULE_8___default()(null, {
    loadableGenerated: {
        modules: [
            "_app.js -> " + "react-hot-toast"
        ]
    },
    ssr: false
});
function App({ Component , pageProps  }) {
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)([]);
    const [err, setErr] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(true);
    const [category, setcategory] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)();
    const [season, setseason] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)();
    const [coupons, setcoupons] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)();
    const [country, setcountry] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)();
    const [metas, setMetas] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)({
        title: data?.siteTitle ? data?.siteTitle : "Home",
        metaTitle: data?.siteTitle ? data?.siteTitle : "",
        metaDescription: `${data?.meta ? data?.meta?.description : ""}`,
        metaKeyword: `${data?.meta ? data?.meta?.keywords : "More Coupon Codes"}`
    });
    (0,react__WEBPACK_IMPORTED_MODULE_9__.useEffect)(()=>{
        async function fetchData() {
            const response = await fetch("/settings/data.json");
            const theme = await response.json();
            setData(theme);
            setcategory(theme?.category);
            setcoupons(theme?.type);
            setseason(theme?.season);
            setcountry(theme?.country);
            setLoading(false);
        }
        fetchData();
    }, []);
    if (loading) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Layout__WEBPACK_IMPORTED_MODULE_5__["default"], {
        title: `${data?.siteTitle ? data?.siteTitle : "Home"}`,
        metaTitle: `${data?.siteTitle ? data?.siteTitle : "Home"}`,
        metaDescription: `${data?.meta ? data?.meta?.description : "More Coupon Codes"}`,
        logo: "",
        metaKeywords: `${data?.meta ? data?.meta?.keywords : "More Coupon Codes"}`,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "bg-white vh-100 vw-100 d-flex justify-content-center align-items-center",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Spinner__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
        })
    });
    if (err) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "text-center error my-auto vw-100 vh-100 d-flex justify-content-center align-items-center",
        children: "Something went wrong!"
    });
    else {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_15___default()), {
                    children: data?.head_scripts && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("script", {
                        dangerouslySetInnerHTML: {
                            __html: data.head_scripts.replace(/<script>/gi, "").replace(/<\/script>/gi, "").trim()
                        },
                        className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default().dynamic([
                            [
                                "736c421bdbb3a08d",
                                [
                                    data?.color?.primary || "green",
                                    data?.color?.secondary || "#1b96b8",
                                    data?.header?.background || "blue",
                                    data?.header?.color || "white",
                                    data?.header?.button_background || "white",
                                    data?.header?.button_color || "white",
                                    data?.footer?.background || "blue",
                                    data?.footer?.color || "white",
                                    data.Style === 4 ? "#ffffff" : "#eeee",
                                    data.Style === 4 ? "neuzeit-grotesk, Calibri" : "Calibri",
                                    data.Style === 4 ? "neuzeit-grotesk" : "Calibri"
                                ]
                            ]
                        ])
                    })
                }),
                react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
                    id: "736c421bdbb3a08d",
                    dynamic: [
                        data?.color?.primary || "green",
                        data?.color?.secondary || "#1b96b8",
                        data?.header?.background || "blue",
                        data?.header?.color || "white",
                        data?.header?.button_background || "white",
                        data?.header?.button_color || "white",
                        data?.footer?.background || "blue",
                        data?.footer?.color || "white",
                        data.Style === 4 ? "#ffffff" : "#eeee",
                        data.Style === 4 ? "neuzeit-grotesk, Calibri" : "Calibri",
                        data.Style === 4 ? "neuzeit-grotesk" : "Calibri"
                    ],
                    children: `:root{--primary:${data?.color?.primary || "green"};--secondary:${data?.color?.secondary || "#1b96b8"};--header:${data?.header?.background || "blue"};--header-text:${data?.header?.color || "white"};--header-btn-bg:${data?.header?.button_background || "white"};--header-btn-text:${data?.header?.button_color || "white"};--footer-bg:${data?.footer?.background || "blue"};--footer-text:${data?.footer?.color || "white"};--body-bg:${data.Style === 4 ? "#ffffff" : "#eeee"};--font-family-body:${data.Style === 4 ? "neuzeit-grotesk, Calibri" : "Calibri"};--font-family-heading:${data.Style === 4 ? "neuzeit-grotesk" : "Calibri"}}`
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default().dynamic([
                        [
                            "736c421bdbb3a08d",
                            [
                                data?.color?.primary || "green",
                                data?.color?.secondary || "#1b96b8",
                                data?.header?.background || "blue",
                                data?.header?.color || "white",
                                data?.header?.button_background || "white",
                                data?.header?.button_color || "white",
                                data?.footer?.background || "blue",
                                data?.footer?.color || "white",
                                data.Style === 4 ? "#ffffff" : "#eeee",
                                data.Style === 4 ? "neuzeit-grotesk, Calibri" : "Calibri",
                                data.Style === 4 ? "neuzeit-grotesk" : "Calibri"
                            ]
                        ]
                    ]) + " " + `_element ${_public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_10__.CONTAINER_TYPE === "wide" ? "wide" : "none-wide"}`,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Layout__WEBPACK_IMPORTED_MODULE_5__["default"], {
                        title: `${metas.title}`,
                        metaTitle: `${metas.metaTitle}`,
                        metaDescription: metas.metaDescription,
                        logo: "",
                        metaKeywords: metas.metaKeyword,
                        children: [
                            data.Style === 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_Header1__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                data: data,
                                category: category,
                                season: season,
                                coupons: coupons,
                                country: country
                            }),
                            data.Style === 2 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_Header2__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                data: data,
                                category: category,
                                season: season,
                                coupons: coupons,
                                country: country
                            }),
                            data.Style === 4 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_Header4__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                data: data,
                                category: category,
                                season: season,
                                coupons: coupons,
                                country: country
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default().dynamic([
                                    [
                                        "736c421bdbb3a08d",
                                        [
                                            data?.color?.primary || "green",
                                            data?.color?.secondary || "#1b96b8",
                                            data?.header?.background || "blue",
                                            data?.header?.color || "white",
                                            data?.header?.button_background || "white",
                                            data?.header?.button_color || "white",
                                            data?.footer?.background || "blue",
                                            data?.footer?.color || "white",
                                            data.Style === 4 ? "#ffffff" : "#eeee",
                                            data.Style === 4 ? "neuzeit-grotesk, Calibri" : "Calibri",
                                            data.Style === 4 ? "neuzeit-grotesk" : "Calibri"
                                        ]
                                    ]
                                ]) + " " + `min-vh-90`,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                                    ...pageProps,
                                    data: data,
                                    metas: metas,
                                    setMetas: setMetas,
                                    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default().dynamic([
                                        [
                                            "736c421bdbb3a08d",
                                            [
                                                data?.color?.primary || "green",
                                                data?.color?.secondary || "#1b96b8",
                                                data?.header?.background || "blue",
                                                data?.header?.color || "white",
                                                data?.header?.button_background || "white",
                                                data?.header?.button_color || "white",
                                                data?.footer?.background || "blue",
                                                data?.footer?.color || "white",
                                                data.Style === 4 ? "#ffffff" : "#eeee",
                                                data.Style === 4 ? "neuzeit-grotesk, Calibri" : "Calibri",
                                                data.Style === 4 ? "neuzeit-grotesk" : "Calibri"
                                            ]
                                        ]
                                    ]) + " " + (pageProps && pageProps.className != null && pageProps.className || "")
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Toaster, {
                                position: "top-right"
                            }),
                            data.Style === 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_Footer1__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                data: data,
                                category: category,
                                season: season,
                                coupons: coupons,
                                country: country
                            }),
                            data.Style === 2 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_Footer2__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                data: data,
                                category: category,
                                season: season,
                                coupons: coupons,
                                country: country
                            }),
                            data.Style === 4 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_Footer4__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                    data: data,
                                    category: category,
                                    season: season,
                                    coupons: coupons,
                                    country: country
                                })
                            })
                        ]
                    })
                })
            ]
        });
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4512:
/***/ (() => {



/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 5832:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9816:
/***/ ((module) => {

"use strict";
module.exports = require("styled-jsx/style");

/***/ }),

/***/ 6201:
/***/ ((module) => {

"use strict";
module.exports = import("react-hot-toast");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,459,664,443,675,298,152,746,321,498,988], () => (__webpack_exec__(8510)));
module.exports = __webpack_exports__;

})();