"use strict";
exports.id = 773;
exports.ids = [773];
exports.modules = {

/***/ 8773:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9816);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2681);
/* harmony import */ var _public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_Spinner__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2670);
// pages/blogs/index.js









const BlogsPage = ({ categoryParam  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const { category: categorySlug  } = router.query;
    const actualCategorySlug = categorySlug || categoryParam;
    const [blogs, setBlogs] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [categories, setCategories] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [tags, setTags] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(true);
    const [loadingBlogs, setLoadingBlogs] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const [imageBaseUrl, setImageBaseUrl] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [selectedCategories, setSelectedCategories] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [selectedTags, setSelectedTags] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [currentPage, setCurrentPage] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(1);
    const [totalPages, setTotalPages] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(1);
    const [totalBlogs, setTotalBlogs] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0);
    const [searchQuery, setSearchQuery] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [selectedCategoryName, setSelectedCategoryName] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [hasInitialized, setHasInitialized] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    // Fetch filter options (categories and tags)
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        const fetchFilterOptions = async ()=>{
            try {
                const response = await fetch(`${_public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_7__.APP_URL}api/v1/blog-filterations?key=${_public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_7__.APP_KEY}&type=featured`);
                if (response.ok) {
                    const result = await response.json();
                    if (result.success && result.data) {
                        const categoriesData = result.data.categories || [];
                        setCategories(categoriesData);
                        setTags(result.data.tags || []);
                        if (actualCategorySlug) {
                            const categorySlugStr = Array.isArray(actualCategorySlug) ? actualCategorySlug[0] : actualCategorySlug;
                            const categoryFromSlug = categoriesData.find((cat)=>cat.slug === categorySlugStr || cat.id.toString() === categorySlugStr);
                            if (categoryFromSlug) {
                                setSelectedCategories([
                                    categoryFromSlug.id
                                ]);
                                setSelectedCategoryName(categoryFromSlug.name);
                            } else {
                                setSelectedCategories([]);
                                setSelectedCategoryName("");
                            }
                        } else {
                            setSelectedCategories([]);
                            setSelectedCategoryName("");
                        }
                        setHasInitialized(true);
                    }
                }
            } catch (err) {
                console.error("Error fetching filter options:", err);
                setHasInitialized(true);
            }
        };
        fetchFilterOptions();
    }, [
        actualCategorySlug
    ]);
    // Fetch blogs with filters
    const fetchBlogs = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(async ()=>{
        if (!hasInitialized || categories.length === 0) return;
        try {
            setLoadingBlogs(true);
            let apiUrl = `${_public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_7__.APP_URL}api/v1/blogs?key=${_public_settings_there_is_nothing_holding_me_back_config__WEBPACK_IMPORTED_MODULE_7__.APP_KEY}&type=featured&page=${currentPage}`;
            // Add category filters
            if (selectedCategories.length > 0) {
                apiUrl += `&categories=${selectedCategories.join(",")}`;
            }
            // Add tag filters
            if (selectedTags.length > 0) {
                apiUrl += `&tags=${selectedTags.join(",")}`;
            }
            // Add search query
            if (searchQuery.trim()) {
                apiUrl += `&search=${encodeURIComponent(searchQuery.trim())}`;
            }
            const response = await fetch(apiUrl);
            if (response.ok) {
                const result = await response.json();
                if (result.success) {
                    setBlogs(result.data || []);
                    setImageBaseUrl(result.url || "");
                    setTotalPages(result.last_page || 1);
                    setTotalBlogs(result.total || 0);
                }
            }
        } catch (err) {
            console.error("Error fetching blogs:", err);
        } finally{
            setLoading(false);
            setLoadingBlogs(false);
        }
    }, [
        selectedCategories,
        selectedTags,
        currentPage,
        searchQuery,
        hasInitialized,
        categories.length
    ]);
    // Initial fetch and when filters change
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (hasInitialized && categories.length > 0) {
            fetchBlogs();
        }
    }, [
        fetchBlogs,
        hasInitialized,
        categories.length
    ]);
    // Handle category selection
    const handleCategoryToggle = (categoryId, categorySlug)=>{
        const isCurrentlySelected = selectedCategories.includes(categoryId);
        if (isCurrentlySelected) {
            setSelectedCategories([]);
            setSelectedCategoryName("");
            router.push("/blogs", undefined, {
                shallow: true
            });
        } else {
            const category = categories.find((cat)=>cat.id === categoryId);
            if (category) {
                setSelectedCategories([
                    categoryId
                ]);
                setSelectedCategoryName(category.name);
                router.push(`/blogs/${category.slug || category.id}`, undefined, {
                    shallow: true
                });
            }
        }
        setSelectedTags([]);
        setCurrentPage(1);
    };
    // Handle tag selection
    const handleTagToggle = (tagId)=>{
        setSelectedTags((prev)=>{
            if (prev.includes(tagId)) {
                return prev.filter((id)=>id !== tagId);
            } else {
                return [
                    ...prev,
                    tagId
                ];
            }
        });
        setCurrentPage(1);
    };
    // Handle search
    const handleSearch = (e)=>{
        e.preventDefault();
        setCurrentPage(1);
        fetchBlogs();
    };
    // Handle page change
    const handlePageChange = (page)=>{
        setCurrentPage(page);
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    };
    // Format date
    const formatDate = (dateString)=>{
        if (!dateString) return "";
        const date = new Date(dateString);
        return date.toLocaleDateString("en-US", {
            year: "numeric",
            month: "short",
            day: "numeric"
        });
    };
    // Clear all filters
    const clearFilters = ()=>{
        setSelectedCategories([]);
        setSelectedTags([]);
        setSearchQuery("");
        setCurrentPage(1);
        setSelectedCategoryName("");
        router.push("/blogs", undefined, {
            shallow: true
        });
    };
    const removeCategory = ()=>{
        setSelectedCategories([]);
        setSelectedCategoryName("");
        setCurrentPage(1);
        router.push("/blogs", undefined, {
            shallow: true
        });
    };
    const removeTag = (tagId)=>{
        setSelectedTags((prev)=>prev.filter((id)=>id !== tagId));
        setCurrentPage(1);
    };
    if (loading && !hasInitialized) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "min-vh-100 d-flex justify-content-center align-items-center",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Spinner__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                size: "lg"
            })
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        className: "jsx-e011656c521773e3",
                        children: selectedCategoryName ? `${selectedCategoryName} | Blog Category` : "Blogs | Our Articles & Insights"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: "Explore our collection of insightful articles, tips, and guides on various topics.",
                        className: "jsx-e011656c521773e3"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "keywords",
                        content: "blog, articles, insights, guides, tips",
                        className: "jsx-e011656c521773e3"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "jsx-e011656c521773e3" + " " + "blogs-page py-5 blogbg",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "jsx-e011656c521773e3" + " " + "hero-section py-5 mb-5 d-none",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "jsx-e011656c521773e3" + " " + "container-fluid",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "jsx-e011656c521773e3" + " " + "row justify-content-center",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "jsx-e011656c521773e3" + " " + "col-lg-10 col-xl-8 text-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                            className: "jsx-e011656c521773e3" + " " + "display-4 fw-bold mb-4",
                                            children: selectedCategoryName || "Our Blog"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "jsx-e011656c521773e3" + " " + "lead mb-0",
                                            children: selectedCategoryName ? `Explore all articles in ${selectedCategoryName} category` : "Discover insightful articles, tips, and guides from our experts"
                                        })
                                    ]
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "jsx-e011656c521773e3" + " " + "container-fluid",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "jsx-e011656c521773e3" + " " + "row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "jsx-e011656c521773e3" + " " + "col-lg-3 mb-4 mb-lg-0",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        style: {
                                            top: "20px"
                                        },
                                        className: "jsx-e011656c521773e3" + " " + "sidebar-filters bg-white p-4 sticky-top",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "jsx-e011656c521773e3" + " " + "mb-5",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                        className: "jsx-e011656c521773e3" + " " + "font-modernMTPro mb-3 text-dark",
                                                        children: "Search Articles"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                                                        onSubmit: handleSearch,
                                                        className: "jsx-e011656c521773e3",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "jsx-e011656c521773e3" + " " + "input-group search-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    type: "text",
                                                                    placeholder: "Search articles...",
                                                                    value: searchQuery,
                                                                    onChange: (e)=>setSearchQuery(e.target.value),
                                                                    className: "jsx-e011656c521773e3" + " " + "form-control search-input"
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                                    type: "submit",
                                                                    className: "jsx-e011656c521773e3" + " " + "button button-primary search-btn",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                            className: "jsx-e011656c521773e3" + " " + "bi bi-search me-2"
                                                                        }),
                                                                        "Search"
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            }),
                                            (selectedCategories.length > 0 || selectedTags.length > 0) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "jsx-e011656c521773e3" + " " + "mb-5",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "jsx-e011656c521773e3" + " " + "d-flex justify-content-between align-items-center mb-3",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                                className: "jsx-e011656c521773e3" + " " + "mb-0 text-dark font-modernMTPro",
                                                                children: "Active Filters"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                onClick: clearFilters,
                                                                className: "jsx-e011656c521773e3" + " " + "btn d-flex align-items-center justify-content-center btn-outline-dark btn-sm font-modernMTPro",
                                                                children: "Clear All"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "jsx-e011656c521773e3" + " " + "d-flex flex-wrap gap-2",
                                                        children: [
                                                            selectedCategories.map((catId)=>{
                                                                const cat = categories.find((c)=>c.id === catId);
                                                                return cat ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                    className: "jsx-e011656c521773e3" + " " + "filter-chip",
                                                                    children: [
                                                                        cat.name,
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                            onClick: ()=>removeCategory(),
                                                                            className: "jsx-e011656c521773e3" + " " + "filter-remove",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                                className: "jsx-e011656c521773e3" + " " + "bi bi-x",
                                                                                children: "x"
                                                                            })
                                                                        })
                                                                    ]
                                                                }, catId) : null;
                                                            }),
                                                            selectedTags.map((tagId)=>{
                                                                const tag = tags.find((t)=>t.id === tagId);
                                                                return tag ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                    className: "jsx-e011656c521773e3" + " " + "filter-chip",
                                                                    children: [
                                                                        tag.name,
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                            onClick: ()=>removeTag(tagId),
                                                                            className: "jsx-e011656c521773e3" + " " + "filter-remove",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                                className: "jsx-e011656c521773e3" + " " + "bi bi-x",
                                                                                children: "x"
                                                                            })
                                                                        })
                                                                    ]
                                                                }, tagId) : null;
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            categories.length > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "jsx-e011656c521773e3" + " " + "mb-5",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                        className: "jsx-e011656c521773e3" + " " + "font-modernMTPro mb-3 text-dark",
                                                        children: "Categories"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "jsx-e011656c521773e3" + " " + "filter-options",
                                                        children: categories.map((category)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                                onClick: ()=>handleCategoryToggle(category.id, category.slug),
                                                                className: "jsx-e011656c521773e3" + " " + `filter-option ${selectedCategories.includes(category.id) ? "active" : ""}`,
                                                                children: [
                                                                    category.name,
                                                                    selectedCategories.includes(category.id) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                        className: "jsx-e011656c521773e3" + " " + "bi bi-check-lg"
                                                                    })
                                                                ]
                                                            }, category.id))
                                                    })
                                                ]
                                            }),
                                            tags.length > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "jsx-e011656c521773e3" + " " + "mb-4",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                        className: "jsx-e011656c521773e3" + " " + "font-modernMTPro mb-3 text-dark",
                                                        children: "Tags"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "jsx-e011656c521773e3" + " " + "filter-options",
                                                        children: tags.map((tag)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                                onClick: ()=>handleTagToggle(tag.id),
                                                                className: "jsx-e011656c521773e3" + " " + `filter-option ${selectedTags.includes(tag.id) ? "active" : ""}`,
                                                                children: [
                                                                    tag.name,
                                                                    selectedTags.includes(tag.id) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                        className: "jsx-e011656c521773e3" + " " + "bi bi-check-lg"
                                                                    })
                                                                ]
                                                            }, tag.id))
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "jsx-e011656c521773e3" + " " + "col-lg-9",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "jsx-e011656c521773e3" + " " + "d-flex justify-content-between align-items-center mb-4",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "jsx-e011656c521773e3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                        className: "jsx-e011656c521773e3" + " " + "h2  mb-2 font-modernMTPro",
                                                        children: searchQuery ? `Search Results for "${searchQuery}"` : selectedCategoryName ? selectedCategoryName : "Latest Articles"
                                                    })
                                                }),
                                                selectedCategoryName && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                    onClick: clearFilters,
                                                    className: "jsx-e011656c521773e3" + " " + "button bg-transparent text-dark font-modernMTPro border-0",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "jsx-e011656c521773e3" + " " + "text-dark",
                                                            children: "View All Categories"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                            className: "jsx-e011656c521773e3" + " " + "fa fa-arrow-right ms-2 text-dark"
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        loadingBlogs ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "jsx-e011656c521773e3" + " " + "text-center py-5",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Spinner__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "jsx-e011656c521773e3" + " " + "mt-3 text-muted",
                                                    children: "Loading articles..."
                                                })
                                            ]
                                        }) : blogs.length > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "jsx-e011656c521773e3" + " " + "row",
                                                    children: blogs.map((blog)=>{
                                                        const imageUrl = blog.image ? `${imageBaseUrl}/${blog.image}` : "/assets/no-image.jpg";
                                                        const formattedDate = formatDate(blog.created_at);
                                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "jsx-e011656c521773e3" + " " + "col-lg-6 col-md-6 mb-4",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "jsx-e011656c521773e3" + " " + "card h-100 border-0 rounded-0 ",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        style: {
                                                                            height: "250px"
                                                                        },
                                                                        className: "jsx-e011656c521773e3" + " " + "position-relative overflow-hidden",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                                            src: imageUrl,
                                                                            alt: blog.title,
                                                                            fill: true,
                                                                            sizes: "(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw",
                                                                            className: "card-img-top rounded-0 object-fit-cover",
                                                                            priority: false
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: "jsx-e011656c521773e3" + " " + "card-body d-flex flex-column px-0",
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                                                className: "jsx-e011656c521773e3" + " " + "card-title text-dark font-modernMTPro",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                                    href: `/blog/${blog.slug}`,
                                                                                    className: "text-decoration-none text-dark",
                                                                                    children: blog.title
                                                                                })
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "jsx-e011656c521773e3" + " " + "flex-grow-1",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    style: {
                                                                                        fontWeight: 500,
                                                                                        lineHeight: 1.6,
                                                                                        display: "-webkit-box",
                                                                                        WebkitLineClamp: 3,
                                                                                        WebkitBoxOrient: "vertical",
                                                                                        overflow: "hidden"
                                                                                    },
                                                                                    dangerouslySetInnerHTML: {
                                                                                        __html: blog.short_description || ""
                                                                                    },
                                                                                    className: "jsx-e011656c521773e3" + " " + "text-dark font-neuzeit-grotesk"
                                                                                })
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "jsx-e011656c521773e3" + " " + "text-muted author-name mb-2",
                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                    className: "jsx-e011656c521773e3" + " " + "text-muted text-uppercase",
                                                                                    children: [
                                                                                        "BY:",
                                                                                        " ",
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                            className: "jsx-e011656c521773e3" + " " + "text-dark",
                                                                                            children: blog.author_name ? blog.author_name : "Unknown"
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                className: "jsx-e011656c521773e3" + " " + "d-flex align-items-center justify-content-between pt-3 border-top",
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                        className: "jsx-e011656c521773e3" + " " + "text-muted small",
                                                                                        children: formattedDate
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                                        href: `/blog/${blog.slug}`,
                                                                                        className: "text-decoration-none font-modernMTPro text-dark small",
                                                                                        children: [
                                                                                            "Read More ",
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                                                className: "jsx-e011656c521773e3" + " " + "fa fa-arrow-right ms-2"
                                                                                            })
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        }, blog.id);
                                                    })
                                                }),
                                                totalPages > 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                                                    "aria-label": "Blog pagination",
                                                    className: "jsx-e011656c521773e3" + " " + "mt-5 pt-4 border-top",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                        className: "jsx-e011656c521773e3" + " " + "pagination justify-content-center",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                className: "jsx-e011656c521773e3" + " " + `page-item ${currentPage === 1 ? "disabled" : ""}`,
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                                    onClick: ()=>handlePageChange(currentPage - 1),
                                                                    disabled: currentPage === 1,
                                                                    className: "jsx-e011656c521773e3" + " " + "page-link",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                            className: "jsx-e011656c521773e3" + " " + "bi bi-chevron-left"
                                                                        }),
                                                                        " Previous"
                                                                    ]
                                                                })
                                                            }),
                                                            Array.from({
                                                                length: Math.min(5, totalPages)
                                                            }, (_, i)=>{
                                                                let pageNum;
                                                                if (totalPages <= 5) {
                                                                    pageNum = i + 1;
                                                                } else if (currentPage <= 3) {
                                                                    pageNum = i + 1;
                                                                } else if (currentPage >= totalPages - 2) {
                                                                    pageNum = totalPages - 4 + i;
                                                                } else {
                                                                    pageNum = currentPage - 2 + i;
                                                                }
                                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                    className: "jsx-e011656c521773e3" + " " + `page-item ${currentPage === pageNum ? "active" : ""}`,
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                        onClick: ()=>handlePageChange(pageNum),
                                                                        className: "jsx-e011656c521773e3" + " " + "page-link",
                                                                        children: pageNum
                                                                    })
                                                                }, pageNum);
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                className: "jsx-e011656c521773e3" + " " + `page-item ${currentPage === totalPages ? "disabled" : ""}`,
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                                    onClick: ()=>handlePageChange(currentPage + 1),
                                                                    disabled: currentPage === totalPages,
                                                                    className: "jsx-e011656c521773e3" + " " + "page-link",
                                                                    children: [
                                                                        "Next ",
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                            className: "jsx-e011656c521773e3" + " " + "bi bi-chevron-right"
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "jsx-e011656c521773e3" + " " + "text-center py-5",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "jsx-e011656c521773e3" + " " + "mb-4",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        className: "jsx-e011656c521773e3" + " " + "bi bi-search display-1 text-muted"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "jsx-e011656c521773e3" + " " + "text-muted mb-4",
                                                    children: searchQuery ? `No articles match your search for "${searchQuery}"` : selectedCategoryName ? `No articles found in "${selectedCategoryName}" category` : "No articles available at the moment"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    onClick: clearFilters,
                                                    className: "jsx-e011656c521773e3" + " " + "button button-primary",
                                                    children: selectedCategoryName ? "View All Categories" : "Clear Filters"
                                                })
                                            ]
                                        }),
                                        blogs.length > 0 && !searchQuery && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "jsx-e011656c521773e3" + " " + "mt-5 pt-5 border-top d-none",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "jsx-e011656c521773e3" + " " + "newsletter-section bg-primary text-white rounded p-5",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "jsx-e011656c521773e3" + " " + "row align-items-center",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "jsx-e011656c521773e3" + " " + "col-lg-8",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                                    className: "jsx-e011656c521773e3" + " " + "fw-bold mb-3",
                                                                    children: "Stay Updated"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                    className: "jsx-e011656c521773e3" + " " + "lead mb-4 opacity-75",
                                                                    children: "Subscribe to our newsletter and never miss our latest articles, tips, and exclusive content."
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                                                    className: "jsx-e011656c521773e3" + " " + "d-flex gap-2 newsletter-form",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                            type: "email",
                                                                            placeholder: "Your email address",
                                                                            className: "jsx-e011656c521773e3" + " " + "form-control newsletter-input"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                            type: "submit",
                                                                            className: "jsx-e011656c521773e3" + " " + "button button-secondary",
                                                                            children: "Subscribe"
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "jsx-e011656c521773e3" + " " + "col-lg-4 text-center",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "jsx-e011656c521773e3" + " " + "newsletter-icon",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                    className: "jsx-e011656c521773e3" + " " + "bi bi-envelope-paper display-1"
                                                                })
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            }),
            react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
                id: "e011656c521773e3",
                children: '.blogs-page{font-family:"Inter",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}.breadcrumb{background:none;padding:0;margin:0}.breadcrumb-item a{color:var(--primary)}.breadcrumb-item.active{color:#6c757d}.shadow-hover{-webkit-box-shadow:0 2px 4px rgba(0,0,0,.1);-moz-box-shadow:0 2px 4px rgba(0,0,0,.1);box-shadow:0 2px 4px rgba(0,0,0,.1);-webkit-transition:all.3s ease;-moz-transition:all.3s ease;-o-transition:all.3s ease;transition:all.3s ease;border:1px solid#f0f0f0}.shadow-hover:hover{-webkit-box-shadow:0 8px 25px rgba(0,0,0,.15);-moz-box-shadow:0 8px 25px rgba(0,0,0,.15);box-shadow:0 8px 25px rgba(0,0,0,.15);-webkit-transform:translatey(-5px);-moz-transform:translatey(-5px);-ms-transform:translatey(-5px);-o-transform:translatey(-5px);transform:translatey(-5px);border-color:#e0e0e0}.card-img-top{-webkit-transition:-webkit-transform.5s ease;-moz-transition:-moz-transform.5s ease;-o-transition:-o-transform.5s ease;transition:-webkit-transform.5s ease;transition:-moz-transform.5s ease;transition:-o-transform.5s ease;transition:transform.5s ease}.shadow-hover:hover .card-img-top{-webkit-transform:scale(1.05);-moz-transform:scale(1.05);-ms-transform:scale(1.05);-o-transform:scale(1.05);transform:scale(1.05)}.filter-chip{display:-webkit-inline-box;display:-webkit-inline-flex;display:-moz-inline-box;display:-ms-inline-flexbox;display:inline-flex;-webkit-box-align:center;-webkit-align-items:center;-moz-box-align:center;-ms-flex-align:center;align-items:center;padding:6px 12px;background:#000;color:white;-webkit-border-radius:20px;-moz-border-radius:20px;border-radius:20px;font-size:13px;font-weight:500}.filter-remove{background:none;border:none;color:white;margin-left:6px;padding:0;width:16px;height:16px;display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-webkit-align-items:center;-moz-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-moz-box-pack:center;-ms-flex-pack:center;justify-content:center;cursor:pointer;opacity:.8}.filter-remove:hover{opacity:1}.filter-options{display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;-webkit-flex-wrap:wrap;-ms-flex-wrap:wrap;flex-wrap:wrap;gap:8px}.filter-option{padding:8px 16px;border:1px solid#dee2e6;-webkit-border-radius:8px;-moz-border-radius:8px;border-radius:8px;background:white;color:#495057;font-size:14px;-webkit-transition:all.2s ease;-moz-transition:all.2s ease;-o-transition:all.2s ease;transition:all.2s ease;cursor:pointer;display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-webkit-align-items:center;-moz-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-moz-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;gap:8px;width:100%;text-align:left}.filter-option:hover{border-color:black;color:var(--primary)}.filter-option.active{background:black;border-color:black;color:white}.page-item.active .page-link{background:black;color:white;border-color:var(--primary);color:white}.page-link{padding:8px 16px;border:1px solid#dee2e6;color:#495057;margin:0 4px;-webkit-border-radius:8px!important;-moz-border-radius:8px!important;border-radius:8px!important}.page-link:hover{background:#f8f9fa;color:var(--primary);border-color:#dee2e6}.newsletter-section{background:-webkit-linear-gradient(315deg,var(--primary)0%,var(--primary)100%);background:-moz-linear-gradient(315deg,var(--primary)0%,var(--primary)100%);background:-o-linear-gradient(315deg,var(--primary)0%,var(--primary)100%);background:linear-gradient(135deg,var(--primary)0%,var(--primary)100%)}@media(max-width:768px){.sidebar-filters{position:static!important}.filter-option{width:-webkit-calc(50% - 4px);width:-moz-calc(50% - 4px);width:calc(50% - 4px)}}'
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BlogsPage);


/***/ })

};
;