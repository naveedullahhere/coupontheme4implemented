module.exports = {
  NEXT_PUBLIC_APP_URL: 'https://helloluvvy.com',
  // NEXT_PUBLIC_APP_URL: 'localhost:3000',
  APP_URL: "https://creativeitsols.com/system/public/",
  APP_KEY: "app_yZWYqQoDaeNDpe6YXZS3hiKcxN20vq0KQDCifCXm",
  DEFAULT_TITLE: "Coupon Codes",
  DEFAULT_DESC: " Coupon Codes",
  CONTAINER_TYPE: "wisde",
  FOOTER_ABOUT:
    "Helloluvvy is the website where you can find latest and verified coupons and promotion codes. Redeem and save now! Big Discounts. Simple Search. Get Code. Big Discount. Always Sale. The Best Price. Paste Code at Checkout. ALmost 5000+ Stores. Redeem Code Online.",
  FOOTER_DESC:
    "Helloluvvy may earn a commission when you purchase a product that is clicked through one of the link.",
};
